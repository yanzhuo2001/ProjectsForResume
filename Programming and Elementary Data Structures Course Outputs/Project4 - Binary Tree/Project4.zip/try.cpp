//
// Created by 16979 on 2022/7/15.
//

#include "binaryTree.h"
#include "huffmanTree.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <vector>
#include <algorithm>

using namespace std;

bool cmp1(char lhs,char rhs)//升序
{
    return lhs<rhs;
}

void deleteNode1 (Node * root) {
    if (root->leftSubtree()!=nullptr) {
        deleteNode1(root->leftSubtree());
    }
    if (root->rightSubtree()!=nullptr){
        deleteNode1(root->rightSubtree());
    }
    delete root;
}

int main(int argc, char *argv[]) {
    //----------------------------------------read file------------------------------------//
    string filename;
    int i,j;
    int judge=0;
    if(argc==2){
        filename=argv[1];
    }
    else if(argc==3){
        filename=argv[2];
    }
    ifstream fin1(filename,ios::in);
    vector<char> letters;
    vector<int>  times;
    char temp;
    fin1.get(temp);
    letters.push_back(temp);
    times.push_back(1);
    while(fin1.get(temp)){
        for(i=0;i<letters.size();i++){
            if(letters[i]==temp){
                judge=1;
                break;
            }
        }
        if(judge==1){                //judge=1 means the letter already exists, then add its corresponding frequency 1
            times[i]++;
        }
        else{                        //the letter doesn't exist, then add it into letters and the original sequence is 1
            letters.push_back(temp);
            times.push_back(1);
        }
        judge=0;                     //reset judge for each loop
    }
    fin1.close();
    //above part is correct, 所有出现的字母都在letters里面，对应的出现的次数在times里面

    //------------------------------------------adjust the order of the letters----------------------------------//
    string temp2;

    vector<char> copyLetters=letters;
    vector<int> copyTimes=times;                                 //copy一份字母和出现次数表
    sort(letters.begin(),letters.end(), cmp1);   //first sort the letters, then find the corresponding times
    for(i=0;i<letters.size();i++){                               //adjust the times to fit letters
        for(j=0;j<letters.size();j++){
            if(letters[i]==copyLetters[j]){
                times[i]=copyTimes[j];
            }
        }
    }
    sort(copyTimes.begin(),copyTimes.end());            //since the letter is unique and time can be same
    int count;
    int count1;
    for(i=0;i<copyTimes.size();i++){
        count=1;                                     //if count=1, means it's the first time that this num appears
        count1=0;
        for(j=0;j<i;j++){
            if(copyTimes[j]==copyTimes[i]){
                count++;
            }
        }
        for(j=0;j<copyTimes.size();j++){
            if(times[j]==copyTimes[i]){
                count1++;
            }
            if(count1==count){
                copyLetters[i]=letters[j];
                break;
            }
        }
    }                                              //此时copyLetters已经按照先times再字母表的升序次序排好
    for(i=0;i<letters.size();i++){                //降序排列出现的次数，可以直接pop掉vector的最后两个
        letters[i]=copyLetters[letters.size()-1-i];
        times[i]=copyTimes[letters.size()-1-i];
    }
    for(i=0;i<letters.size();i++){                //let copy be the same as the 降序排好的 vector
        copyLetters[i]=letters[i];
        copyTimes[i]=times[i];
    }
    vector<string> copyLetters2;                //another copy of letters, but use a string vector instead of a char vector
    for(i=0;i<letters.size();i++){
        temp2=letters[i];
        copyLetters2.push_back(temp2);
    }
    vector<int> copyTimes2=times;
    //above part is correct, 所有vector中都是先次数降序排列然后对应的字母降序排列



    return 0;

}